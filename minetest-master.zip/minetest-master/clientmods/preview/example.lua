print("Loaded example file!, loading more examples")
dofile("preview:examples/first.lua")
